/**
 * Created by Administrator on 2016/9/18.
 */
//创建容器对象
function holder(){
    this.box=document.getElementById("box");
}
//创建我方飞机
function myplane(blood){
    holder.call(this);
    this.blood=blood;
    this.init();
    this.create();
    this.move();
}
myplane.prototype={
    init:function(){
        this.boxW=this.box.clientWidth;
        this.boxH=this.box.clientHeight;
        this.pos = {
            x:157,
            y:474
        }
    },
    create:function(){
        var box=this.box;
        this.plane=document.createElement("div");
        this.plane.blood=this.blood;
        this.plane.className="myplane";
        box.appendChild(this.plane);

    },
    move:function(){
        var box=this.box;
        var w=this.boxW;
        var h=this.boxH;
        var plane=this.plane;
        var self=this;
        box.onmousemove=function(event){
            var ev=window.event||event;
            var _left= (ev.offsetX|| ev.layerX)-plane.offsetWidth/2;
            var _top=(ev.offsetY|| ev.layerY)-plane.offsetHeight/2;
            if(_left<=-plane.offsetWidth/2){
                _left=-plane.offsetWidth/2;
            }else if(_left>=w-plane.offsetWidth/2){
                _left=w-plane.offsetWidth/2;
            }
            if(_top<=0){
                _top=0;
            }else if(_top>=h-plane.offsetHeight){
                _top=h-plane.offsetHeight;
            }
            self.pos.x=_left+plane.offsetWidth/2;
            self.pos.y=_top;
            plane.style.top=_top+"px";
            plane.style.left=_left+"px";
        }
    }
}
//创建子弹
function bullet(spacing){
    holder.call(this);
    this.spacing=spacing;

    this.create();
    this.loop();
}
bullet.prototype={
    init:function(){},
    create:function(){
        var box=this.box;
        var biu=document.createElement("span");
        biu.className="biu";
        box.appendChild(biu);
        //初始化子弹初始位置
        biu.style.left = (plane.pos.x) + 'px';
        biu.style.top = (plane.pos.y-14) + 'px';
        biu.t=plane.pos.y-14;
        biu.timer=setInterval(function(){
            biu.t-=2;
            if(biu.t<=0){
                clearInterval(biu.timer);
                box.removeChild(biu);
            }
            biu.style.top=biu.t+"px";
        },10)
    },
    loop:function(){
        var self=this;
        this.timer=setInterval(function(){
            self.create();
        },this.spacing)
    }
}
//创建敌机
function diji(blood,speed,spacing,class1,class2){
    holder.call(this)
    this.blood=blood;
    this.speed=speed;
    this.spacing=spacing;
    this.class1=class1;
    this.class2=class2;
    this.init();
    this.loop();
}
diji.prototype={
    init:function(){
        this.boxW=this.box.clientWidth;
        this.boxH=this.box.clientHeight;
    },
    create:function(){
        var box=this.box;
        var w=this.boxW;
        var h=this.boxH;
        var speed=this.speed;
        var class1=this.class1;
        var class2=this.class2;
        var blood=this.blood;
        var tplane=document.createElement("div");
        tplane.className=class1;
        box.appendChild(tplane);
        tplane.style.left=Math.floor(Math.random()*(w-tplane.offsetWidth))+"px";
        tplane.style.top=-tplane.offsetHeight+"px";
        tplane.t=tplane.offsetTop;
        tplane.h=tplane.offsetHeight;
        tplane.w=tplane.offsetWidth;
        tplane.l=tplane.offsetLeft;
        tplane.b=blood;
        tplane.timer=setInterval(function(){
            tplane.t+=speed;
            //边界检测
            if(tplane.t>=h){
                clearInterval(tplane.timer);
                box.removeChild(tplane);
            }
            //碰撞检测
            var bius=document.getElementsByTagName("span");
            for(var i=0;i<bius.length;i++) {
                var _biu = bius[i];
                if (tplane.t + tplane.h >= _biu.t &&tplane.t<=_biu.t+_biu.offsetHeight&& (_biu.offsetLeft + _biu.offsetWidth) >= tplane.l && _biu.offsetLeft <= tplane.l + tplane.w) {
                    tplane.b--;
                    clearInterval(_biu.timer);
                    box.removeChild(_biu);
                    console.log(tplane.b)
                    if (tplane.b <= 0) {
                        tplane.className = class2;
                        clearInterval(tplane.timer);
                        setTimeout(function () {
                            box.removeChild(tplane);
                        }, 500)
                    }
                }
            }
            //  互相伤害
            var res=document.getElementById("restart");
            var btnr=document.getElementById("btn1");
            var btnc=document.getElementById("btn2");
            var mp=plane.plane;
            if(mp.offsetTop<tplane.t+tplane.h&&(mp.offsetLeft+mp.offsetWidth)>=tplane.l&&mp.offsetLeft<=tplane.l+tplane.w&&tplane.t<=mp.offsetTop+mp.offsetHeight) {
                mp.blood--;
                tplane.t = 0;
                tplane.className = class2;
                clearInterval(tplane.timer);
                setTimeout(function () {
                    box.removeChild(tplane);
                }, 500)
                if (mp.blood <= 0) {
                    mp.className = "myplane2";
                    box.onmousemove=null;
                    clearInterval(biu.timer);
                    clearInterval(plane1.timer);
                    clearInterval(plane2.timer);
                    clearInterval(plane3.timer);
                    //var str=document.createElement("h1");
                    //str.innerHTML="游戏结束"
                    //str.className="str1"
                    setTimeout(function () {
                        //clearInterval(biu.timer);
                        //clearInterval(plane1.timer);
                        //clearInterval(plane2.timer);
                        //clearInterval(plane3.timer);
                        box.removeChild(mp);
                        //box.innerHTML="";
                        res.style.display="block";
                        btnr.onclick=function(){
                            window.location.reload();
                        }
                        btnc.onclick=function(){
                            window.close();
                        }
                        //box.innerHTML+="游戏结束";
                        //var isCon = confirm("是否继续?");
                        //if(isCon){
                        //    window.location.reload();
                        //}else{
                        //    window.close();
                        //}
                    }, 500)

                }
            }
            tplane.style.top=tplane.t+"px";
        },10)
    },
    loop:function(){
        var self=this;
        this.timer=setInterval(function(){
            self.create();
        },this.spacing)
    }
}